# Money_Saver

VIDEO LINKS:- https://youtu.be/abTF4kKch14

I created Money_Saver dekstop application which Track the Amazon/Flipkart product prices and send Email if current price of product is 
less than or equivalent to our Desired price...

As u know price of any product is not static on ecommerce site, it continuously increasing/Decreasing  and we as a humen always wanted to buy 
a product at least price , and its very tds task to check prices regularly & even it's more diffucult when it comes to more than one product.

That's my motivation behind this project to solve this issue...

My application Included GUI ,Database on cloud plateform, Wayscript & Web Scraping tools.



GUI - Tkinter module designed in figma ,
Database- mysql !.e hosted on Clever cloud plateform
and script for price tracking is made using Beautifulsoup an request module 
& for Email i used smtplib module. and I deploy this script on WayScript for secheduling the program and i sechedule this task on everyday 
basics that is automatically run ,it Fetch one by one URL and Desirable price from databases and sends the mail if requirement satisfied.
